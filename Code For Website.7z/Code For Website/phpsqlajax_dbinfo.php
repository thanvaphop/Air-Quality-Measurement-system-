<?php
$username="id16513288_admin";
$password="wR/oi2p[ghL8/U%H";
$database="id16513288_gases";
$con=mysqli_connect("localhost",$username,$password,$database);
?>